This script by Baranov Alexey contains Blitz class API to have 
autocomplete and method/parameter descriptions in Zend Studio. 
